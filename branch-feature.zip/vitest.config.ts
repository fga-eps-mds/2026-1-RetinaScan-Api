import { defineConfig } from 'vitest/config';
import path from 'node:path';

const alias = { '@': path.resolve(import.meta.dirname, 'src') };

export default defineConfig({
  resolve: {
    alias: {
      '@': path.resolve(import.meta.dirname, 'src'),
    },
  },
  test: {
    globals: true,
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html', 'lcov'],
      reportsDirectory: './coverage',
      include: ['src/**/*.ts'],
      exclude: [
        'src/types/**',
        'src/server.ts',
        'src/tests/**',
        '**/index.ts',
        'src/infra/container/**',
        'src/infra/storage/**',
        'src/infra/auth/**',
        'src/infra/health/**',
        'src/infra/docs/**',
        'src/infra/database/drizzle/schema/**',
        'src/infra/database/drizzle/migrate.ts',
      ],
    },
    projects: [
      {
        resolve: { alias },
        test: {
          name: 'unit',
          globals: true,
          environment: 'node',
          include: ['src/tests/unit/**/*.test.ts'],
          typecheck: { tsconfig: './tsconfig.test.json' },
          sequence: { groupOrder: 0 },
        },
      },
      {
        resolve: { alias },
        test: {
          name: 'integration',
          globals: true,
          environment: 'node',
          include: ['src/tests/integration/**/*.test.ts'],
          globalSetup: ['src/tests/integration/setup/global-setup.ts'],
          typecheck: { tsconfig: './tsconfig.test.json' },
          pool: 'forks',
          maxWorkers: 1,
          isolate: false,
          fileParallelism: false,
          sequence: { groupOrder: 1 },
        },
      },
    ],
  },
});
